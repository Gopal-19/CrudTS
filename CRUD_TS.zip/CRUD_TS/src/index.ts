
import {MongoClient} from 'mongodb';




class Main{
    static main(){
        Main.update();
    }
    //find
    static async find(){
        const url = 'mongodb://localhost:27017';
        const client = await MongoClient.connect(url);
        const db = client.db('cdac');
      

        const docs = await db.collection('test').find().toArray();
        for (let i = 0; i<docs.length; i++){
            let item = docs[i];
            console.log(item);

        }
        //docs.forEach(item => console.log(item));
        client.close(); 
    }

    //insert
    static async insert(){
        const url = 'mongodb://localhost:27017';
        const client = await MongoClient.connect(url);
        const db = client.db('cdac');
      

        const output = await db.collection('test').insertOne({todo: 'Hello mongo'});
        console.log(output);
        client.close(); 
    }
    //delete
    static async delete(){
        const url = 'mongodb://localhost:27017';
        const client = await MongoClient.connect(url);
        const db = client.db('cdac');
      

        const output = await db.collection('test').deleteOne({todo: 'Hello mongo'});
        console.log(output);
        client.close(); 


}
static async update(){
    const url = 'mongodb://localhost:27017';
    const client = await MongoClient.connect(url);
    const db = client.db('cdac');
  

    const output = await db.collection('test').updateOne({todo: 'Hello mongo'},{$set: {todo: 'Hello PESU'}});
    console.log(output);
    client.close(); 
}


}

Main.main();